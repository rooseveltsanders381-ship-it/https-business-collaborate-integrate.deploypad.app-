import { createClient } from "@supabase/supabase-js";

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

export default async function handler(req, res) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Missing authorization header" });
  }
  const token = authHeader.split(" ")[1];
  if (token !== process.env.GUARDIAN_KEY) {
    return res.status(403).json({ error: "Invalid token" });
  }
  try {
    const results = [];
    for (let i = 1; i <= 33; i++) {
      const platform = `platform${i}`;
      const { data, error } = await supabase.from(`${platform}_status`).select("*").limit(1);
      results.push({ platform, status: error ? "DOWN" : "UP" });
    }
    res.status(200).json({ results });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}