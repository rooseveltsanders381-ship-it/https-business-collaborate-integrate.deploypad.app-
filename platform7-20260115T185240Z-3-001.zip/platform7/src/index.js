import express from "express";

const app = express();
const port = process.env.PORT || 3000;

app.get("/", (req, res) => {
  res.send("platform7 running ✅");
});

app.listen(port, () => {
  console.log("platform7 running on port " + port);
});
