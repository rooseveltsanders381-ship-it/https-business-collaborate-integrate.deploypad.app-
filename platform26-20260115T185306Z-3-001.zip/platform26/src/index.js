import express from "express";

const app = express();
const port = process.env.PORT || 3000;

app.get("/", (req, res) => {
  res.send("platform26 running ✅");
});

app.listen(port, () => {
  console.log("platform26 running on port " + port);
});
