import express from "express";

const app = express();
const port = process.env.PORT || 3000;

app.get("/", (req, res) => {
  res.send("platform24 running ✅");
});

app.listen(port, () => {
  console.log("platform24 running on port " + port);
});
